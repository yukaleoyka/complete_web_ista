import os
import time
from datetime import datetime

from flask import Flask, flash, redirect, render_template, request, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func, or_
from sqlalchemy.exc import IntegrityError

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'ista-dev-secret')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv(
    'DATABASE_URL',
    'postgresql+psycopg2://ista_user:ista_pass@db:5432/ista_campus'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


class Department(db.Model):
    __tablename__ = 'departments'
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(120), unique=True, nullable=False)
    head_name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Lecturer(db.Model):
    __tablename__ = 'lecturers'
    id = db.Column(db.Integer, primary_key=True)
    nidn = db.Column(db.String(30), unique=True, nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    expertise = db.Column(db.String(120), nullable=True)
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    department = db.relationship('Department', backref=db.backref('lecturers', lazy=True))


class Student(db.Model):
    __tablename__ = 'students'
    id = db.Column(db.Integer, primary_key=True)
    nim = db.Column(db.String(30), unique=True, nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    cohort = db.Column(db.Integer, nullable=False)
    class_group = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='Aktif')
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    department = db.relationship('Department', backref=db.backref('students', lazy=True))


class Course(db.Model):
    __tablename__ = 'courses'
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(150), nullable=False)
    credits = db.Column(db.Integer, nullable=False)
    semester = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, nullable=True)
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=False)
    lecturer_id = db.Column(db.Integer, db.ForeignKey('lecturers.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    department = db.relationship('Department', backref=db.backref('courses', lazy=True))
    lecturer = db.relationship('Lecturer', backref=db.backref('courses', lazy=True))


class CampusClass(db.Model):
    __tablename__ = 'campus_classes'
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(30), unique=True, nullable=False)
    room = db.Column(db.String(50), nullable=False)
    schedule = db.Column(db.String(100), nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    lecturer_id = db.Column(db.Integer, db.ForeignKey('lecturers.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    course = db.relationship('Course', backref=db.backref('campus_classes', lazy=True))
    lecturer = db.relationship('Lecturer', backref=db.backref('campus_classes', lazy=True))


class Enrollment(db.Model):
    __tablename__ = 'enrollments'
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    campus_class_id = db.Column(db.Integer, db.ForeignKey('campus_classes.id'), nullable=False)
    grade = db.Column(db.String(5), nullable=True)
    note = db.Column(db.String(200), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    student = db.relationship('Student', backref=db.backref('enrollments', lazy=True, cascade='all, delete-orphan'))
    campus_class = db.relationship('CampusClass', backref=db.backref('enrollments', lazy=True, cascade='all, delete-orphan'))

    __table_args__ = (
        db.UniqueConstraint('student_id', 'campus_class_id', name='uq_student_class'),
    )


def wait_for_db(max_attempts: int = 25, delay: int = 2) -> None:
    attempt = 1
    while attempt <= max_attempts:
        try:
            db.session.execute(db.text('SELECT 1'))
            db.session.commit()
            return
        except Exception:
            db.session.rollback()
            time.sleep(delay)
            attempt += 1
    raise RuntimeError('Database is not ready after multiple attempts.')


def seed_data() -> None:
    if Department.query.count() > 0:
        return

    departments = [
        Department(code='IF', name='Informatika', head_name='Dr. Raka Pratama', description='Fokus pada rekayasa perangkat lunak, data, AI, dan jaringan.'),
        Department(code='SI', name='Sistem Informasi', head_name='Dr. Nisa Kamilah', description='Fokus pada analisis bisnis, tata kelola SI, dan transformasi digital.'),
        Department(code='TE', name='Teknik Elektro', head_name='Dr. Fajar Nugraha', description='Fokus pada sistem tenaga, kontrol, dan elektronika.'),
    ]
    db.session.add_all(departments)
    db.session.flush()

    lecturers = [
        Lecturer(nidn='010101001', full_name='Dr. Aulia Rahman', email='aulia.rahman@ista.ac.id', expertise='Machine Learning', department_id=departments[0].id),
        Lecturer(nidn='010101002', full_name='M. Taufik Hidayat, M.Kom', email='taufik.hidayat@ista.ac.id', expertise='Web Development', department_id=departments[0].id),
        Lecturer(nidn='010101003', full_name='Nabila Salsabila, M.Kom', email='nabila.salsabila@ista.ac.id', expertise='Database Systems', department_id=departments[1].id),
        Lecturer(nidn='010101004', full_name='Dr. Yudi Firmansyah', email='yudi.firmansyah@ista.ac.id', expertise='Embedded Systems', department_id=departments[2].id),
        Lecturer(nidn='010101005', full_name='Rina Lestari, M.T', email='rina.lestari@ista.ac.id', expertise='Data Governance', department_id=departments[1].id),
    ]
    db.session.add_all(lecturers)
    db.session.flush()

    students = [
        Student(nim='2311001', full_name='Alif Prakoso', email='2311001@student.ista.ac.id', cohort=2023, class_group='IF-2A', status='Aktif', department_id=departments[0].id),
        Student(nim='2311002', full_name='Dinda Kurnia', email='2311002@student.ista.ac.id', cohort=2023, class_group='IF-2A', status='Aktif', department_id=departments[0].id),
        Student(nim='2311003', full_name='Fauzan Maulana', email='2311003@student.ista.ac.id', cohort=2023, class_group='IF-2B', status='Aktif', department_id=departments[0].id),
        Student(nim='2311004', full_name='Mira Azzahra', email='2311004@student.ista.ac.id', cohort=2023, class_group='SI-2A', status='Aktif', department_id=departments[1].id),
        Student(nim='2311005', full_name='Nadya Puspita', email='2311005@student.ista.ac.id', cohort=2023, class_group='SI-2A', status='Aktif', department_id=departments[1].id),
        Student(nim='2311006', full_name='Rafli Akbar', email='2311006@student.ista.ac.id', cohort=2023, class_group='TE-2A', status='Aktif', department_id=departments[2].id),
        Student(nim='2212001', full_name='Sinta Maharani', email='2212001@student.ista.ac.id', cohort=2022, class_group='IF-4A', status='Aktif', department_id=departments[0].id),
        Student(nim='2212002', full_name='Vino Ramadhan', email='2212002@student.ista.ac.id', cohort=2022, class_group='IF-4B', status='Cuti', department_id=departments[0].id),
    ]
    db.session.add_all(students)
    db.session.flush()

    courses = [
        Course(code='IF201', name='Pemrograman Web', credits=3, semester=4, description='Dasar pengembangan web modern.', department_id=departments[0].id, lecturer_id=lecturers[1].id),
        Course(code='IF305', name='Machine Learning', credits=3, semester=6, description='Model supervised dan evaluasi model.', department_id=departments[0].id, lecturer_id=lecturers[0].id),
        Course(code='SI203', name='Basis Data Lanjut', credits=3, semester=4, description='Optimasi query dan desain relasional.', department_id=departments[1].id, lecturer_id=lecturers[2].id),
        Course(code='SI301', name='Manajemen Proyek TI', credits=2, semester=5, description='Perencanaan, monitoring, dan delivery proyek.', department_id=departments[1].id, lecturer_id=lecturers[4].id),
        Course(code='TE210', name='Mikrokontroler', credits=3, semester=4, description='Pemrograman dan antarmuka perangkat.', department_id=departments[2].id, lecturer_id=lecturers[3].id),
    ]
    db.session.add_all(courses)
    db.session.flush()

    campus_classes = [
        CampusClass(code='IF201-A', room='Lab Komputer 1', schedule='Senin 08:00 - 10:30', capacity=35, course_id=courses[0].id, lecturer_id=lecturers[1].id),
        CampusClass(code='IF305-A', room='Ruang C302', schedule='Rabu 10:00 - 12:30', capacity=30, course_id=courses[1].id, lecturer_id=lecturers[0].id),
        CampusClass(code='SI203-A', room='Ruang B201', schedule='Selasa 13:00 - 15:30', capacity=32, course_id=courses[2].id, lecturer_id=lecturers[2].id),
        CampusClass(code='TE210-A', room='Lab Embedded', schedule='Kamis 09:00 - 11:30', capacity=24, course_id=courses[4].id, lecturer_id=lecturers[3].id),
    ]
    db.session.add_all(campus_classes)
    db.session.flush()

    enrollments = [
        Enrollment(student_id=students[0].id, campus_class_id=campus_classes[0].id, grade='A', note='Aktif'),
        Enrollment(student_id=students[1].id, campus_class_id=campus_classes[0].id, grade='A-', note='Aktif'),
        Enrollment(student_id=students[2].id, campus_class_id=campus_classes[1].id, grade='B+', note='Aktif'),
        Enrollment(student_id=students[3].id, campus_class_id=campus_classes[2].id, grade='A', note='Aktif'),
        Enrollment(student_id=students[4].id, campus_class_id=campus_classes[2].id, grade='B', note='Perlu remedial minor'),
        Enrollment(student_id=students[5].id, campus_class_id=campus_classes[3].id, grade='A-', note='Aktif'),
        Enrollment(student_id=students[6].id, campus_class_id=campus_classes[1].id, grade='A', note='Asisten praktikum'),
    ]
    db.session.add_all(enrollments)
    db.session.commit()


def bootstrap() -> None:
    wait_for_db()
    db.create_all()
    seed_data()


with app.app_context():
    bootstrap()


@app.context_processor
def inject_now():
    return {'now_year': datetime.utcnow().year}


@app.route('/')
def dashboard():
    stats = {
        'departments': Department.query.count(),
        'lecturers': Lecturer.query.count(),
        'students': Student.query.count(),
        'courses': Course.query.count(),
        'classes': CampusClass.query.count(),
        'enrollments': Enrollment.query.count(),
    }
    active_students = Student.query.filter_by(status='Aktif').count()
    recent_students = Student.query.order_by(Student.created_at.desc()).limit(5).all()
    recent_courses = Course.query.order_by(Course.created_at.desc()).limit(5).all()
    top_departments = (
        db.session.query(Department.name, func.count(Student.id))
        .outerjoin(Student, Student.department_id == Department.id)
        .group_by(Department.name)
        .order_by(func.count(Student.id).desc())
        .all()
    )
    return render_template(
        'dashboard.html',
        stats=stats,
        active_students=active_students,
        recent_students=recent_students,
        recent_courses=recent_courses,
        top_departments=top_departments,
    )


@app.route('/departments')
def departments():
    q = request.args.get('q', '').strip()
    query = Department.query
    if q:
        query = query.filter(or_(Department.code.ilike(f'%{q}%'), Department.name.ilike(f'%{q}%'), Department.head_name.ilike(f'%{q}%')))
    items = query.order_by(Department.name.asc()).all()
    return render_template('departments.html', items=items, q=q)


@app.route('/departments/add', methods=['GET', 'POST'])
def department_add():
    if request.method == 'POST':
        item = Department(
            code=request.form['code'].strip(),
            name=request.form['name'].strip(),
            head_name=request.form['head_name'].strip(),
            description=request.form.get('description', '').strip() or None,
        )
        db.session.add(item)
        return save_and_redirect('Data jurusan berhasil ditambahkan.', 'department_form.html', item=item)
    return render_template('department_form.html', item=None)


@app.route('/departments/<int:item_id>/edit', methods=['GET', 'POST'])
def department_edit(item_id):
    item = Department.query.get_or_404(item_id)
    if request.method == 'POST':
        item.code = request.form['code'].strip()
        item.name = request.form['name'].strip()
        item.head_name = request.form['head_name'].strip()
        item.description = request.form.get('description', '').strip() or None
        return save_and_redirect('Data jurusan berhasil diperbarui.', 'department_form.html', item=item)
    return render_template('department_form.html', item=item)


@app.post('/departments/<int:item_id>/delete')
def department_delete(item_id):
    item = Department.query.get_or_404(item_id)
    if item.students or item.lecturers or item.courses:
        flash('Jurusan tidak dapat dihapus karena masih dipakai oleh data lain.', 'error')
        return redirect(url_for('departments'))
    db.session.delete(item)
    db.session.commit()
    flash('Data jurusan berhasil dihapus.', 'success')
    return redirect(url_for('departments'))


@app.route('/lecturers')
def lecturers():
    q = request.args.get('q', '').strip()
    query = Lecturer.query.join(Department)
    if q:
        query = query.filter(or_(Lecturer.nidn.ilike(f'%{q}%'), Lecturer.full_name.ilike(f'%{q}%'), Lecturer.email.ilike(f'%{q}%'), Department.name.ilike(f'%{q}%')))
    items = query.order_by(Lecturer.full_name.asc()).all()
    return render_template('lecturers.html', items=items, q=q)


@app.route('/lecturers/add', methods=['GET', 'POST'])
def lecturer_add():
    departments = Department.query.order_by(Department.name.asc()).all()
    if request.method == 'POST':
        item = Lecturer(
            nidn=request.form['nidn'].strip(),
            full_name=request.form['full_name'].strip(),
            email=request.form['email'].strip(),
            expertise=request.form.get('expertise', '').strip() or None,
            department_id=int(request.form['department_id']),
        )
        db.session.add(item)
        return save_and_redirect('Data dosen berhasil ditambahkan.', 'lecturer_form.html', item=item, departments=departments)
    return render_template('lecturer_form.html', item=None, departments=departments)


@app.route('/lecturers/<int:item_id>/edit', methods=['GET', 'POST'])
def lecturer_edit(item_id):
    item = Lecturer.query.get_or_404(item_id)
    departments = Department.query.order_by(Department.name.asc()).all()
    if request.method == 'POST':
        item.nidn = request.form['nidn'].strip()
        item.full_name = request.form['full_name'].strip()
        item.email = request.form['email'].strip()
        item.expertise = request.form.get('expertise', '').strip() or None
        item.department_id = int(request.form['department_id'])
        return save_and_redirect('Data dosen berhasil diperbarui.', 'lecturer_form.html', item=item, departments=departments)
    return render_template('lecturer_form.html', item=item, departments=departments)


@app.post('/lecturers/<int:item_id>/delete')
def lecturer_delete(item_id):
    item = Lecturer.query.get_or_404(item_id)
    if item.courses or item.campus_classes:
        flash('Dosen tidak dapat dihapus karena masih terhubung dengan mata kuliah atau kelas.', 'error')
        return redirect(url_for('lecturers'))
    db.session.delete(item)
    db.session.commit()
    flash('Data dosen berhasil dihapus.', 'success')
    return redirect(url_for('lecturers'))


@app.route('/students')
def students():
    q = request.args.get('q', '').strip()
    query = Student.query.join(Department)
    if q:
        query = query.filter(or_(Student.nim.ilike(f'%{q}%'), Student.full_name.ilike(f'%{q}%'), Student.class_group.ilike(f'%{q}%'), Department.name.ilike(f'%{q}%')))
    items = query.order_by(Student.full_name.asc()).all()
    return render_template('students.html', items=items, q=q)


@app.route('/students/add', methods=['GET', 'POST'])
def student_add():
    departments = Department.query.order_by(Department.name.asc()).all()
    if request.method == 'POST':
        item = Student(
            nim=request.form['nim'].strip(),
            full_name=request.form['full_name'].strip(),
            email=request.form['email'].strip(),
            cohort=int(request.form['cohort']),
            class_group=request.form['class_group'].strip(),
            status=request.form['status'].strip(),
            department_id=int(request.form['department_id']),
        )
        db.session.add(item)
        return save_and_redirect('Data mahasiswa berhasil ditambahkan.', 'student_form.html', item=item, departments=departments)
    return render_template('student_form.html', item=None, departments=departments)


@app.route('/students/<int:item_id>/edit', methods=['GET', 'POST'])
def student_edit(item_id):
    item = Student.query.get_or_404(item_id)
    departments = Department.query.order_by(Department.name.asc()).all()
    if request.method == 'POST':
        item.nim = request.form['nim'].strip()
        item.full_name = request.form['full_name'].strip()
        item.email = request.form['email'].strip()
        item.cohort = int(request.form['cohort'])
        item.class_group = request.form['class_group'].strip()
        item.status = request.form['status'].strip()
        item.department_id = int(request.form['department_id'])
        return save_and_redirect('Data mahasiswa berhasil diperbarui.', 'student_form.html', item=item, departments=departments)
    return render_template('student_form.html', item=item, departments=departments)


@app.post('/students/<int:item_id>/delete')
def student_delete(item_id):
    item = Student.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    flash('Data mahasiswa berhasil dihapus.', 'success')
    return redirect(url_for('students'))


@app.route('/courses')
def courses():
    q = request.args.get('q', '').strip()
    query = Course.query.join(Department).join(Lecturer)
    if q:
        query = query.filter(or_(Course.code.ilike(f'%{q}%'), Course.name.ilike(f'%{q}%'), Department.name.ilike(f'%{q}%'), Lecturer.full_name.ilike(f'%{q}%')))
    items = query.order_by(Course.code.asc()).all()
    return render_template('courses.html', items=items, q=q)


@app.route('/courses/add', methods=['GET', 'POST'])
def course_add():
    departments = Department.query.order_by(Department.name.asc()).all()
    lecturers = Lecturer.query.order_by(Lecturer.full_name.asc()).all()
    if request.method == 'POST':
        item = Course(
            code=request.form['code'].strip(),
            name=request.form['name'].strip(),
            credits=int(request.form['credits']),
            semester=int(request.form['semester']),
            description=request.form.get('description', '').strip() or None,
            department_id=int(request.form['department_id']),
            lecturer_id=int(request.form['lecturer_id']),
        )
        db.session.add(item)
        return save_and_redirect('Data mata kuliah berhasil ditambahkan.', 'course_form.html', item=item, departments=departments, lecturers=lecturers)
    return render_template('course_form.html', item=None, departments=departments, lecturers=lecturers)


@app.route('/courses/<int:item_id>/edit', methods=['GET', 'POST'])
def course_edit(item_id):
    item = Course.query.get_or_404(item_id)
    departments = Department.query.order_by(Department.name.asc()).all()
    lecturers = Lecturer.query.order_by(Lecturer.full_name.asc()).all()
    if request.method == 'POST':
        item.code = request.form['code'].strip()
        item.name = request.form['name'].strip()
        item.credits = int(request.form['credits'])
        item.semester = int(request.form['semester'])
        item.description = request.form.get('description', '').strip() or None
        item.department_id = int(request.form['department_id'])
        item.lecturer_id = int(request.form['lecturer_id'])
        return save_and_redirect('Data mata kuliah berhasil diperbarui.', 'course_form.html', item=item, departments=departments, lecturers=lecturers)
    return render_template('course_form.html', item=item, departments=departments, lecturers=lecturers)


@app.post('/courses/<int:item_id>/delete')
def course_delete(item_id):
    item = Course.query.get_or_404(item_id)
    if item.campus_classes:
        flash('Mata kuliah tidak dapat dihapus karena masih memiliki kelas aktif.', 'error')
        return redirect(url_for('courses'))
    db.session.delete(item)
    db.session.commit()
    flash('Data mata kuliah berhasil dihapus.', 'success')
    return redirect(url_for('courses'))


@app.route('/classes')
def classes():
    q = request.args.get('q', '').strip()
    query = CampusClass.query.join(Course).join(Lecturer)
    if q:
        query = query.filter(or_(CampusClass.code.ilike(f'%{q}%'), CampusClass.room.ilike(f'%{q}%'), Course.name.ilike(f'%{q}%'), Lecturer.full_name.ilike(f'%{q}%')))
    items = query.order_by(CampusClass.code.asc()).all()
    return render_template('classes.html', items=items, q=q)


@app.route('/classes/add', methods=['GET', 'POST'])
def class_add():
    courses = Course.query.order_by(Course.code.asc()).all()
    lecturers = Lecturer.query.order_by(Lecturer.full_name.asc()).all()
    if request.method == 'POST':
        item = CampusClass(
            code=request.form['code'].strip(),
            room=request.form['room'].strip(),
            schedule=request.form['schedule'].strip(),
            capacity=int(request.form['capacity']),
            course_id=int(request.form['course_id']),
            lecturer_id=int(request.form['lecturer_id']),
        )
        db.session.add(item)
        return save_and_redirect('Data kelas berhasil ditambahkan.', 'class_form.html', item=item, courses=courses, lecturers=lecturers)
    return render_template('class_form.html', item=None, courses=courses, lecturers=lecturers)


@app.route('/classes/<int:item_id>/edit', methods=['GET', 'POST'])
def class_edit(item_id):
    item = CampusClass.query.get_or_404(item_id)
    courses = Course.query.order_by(Course.code.asc()).all()
    lecturers = Lecturer.query.order_by(Lecturer.full_name.asc()).all()
    if request.method == 'POST':
        item.code = request.form['code'].strip()
        item.room = request.form['room'].strip()
        item.schedule = request.form['schedule'].strip()
        item.capacity = int(request.form['capacity'])
        item.course_id = int(request.form['course_id'])
        item.lecturer_id = int(request.form['lecturer_id'])
        return save_and_redirect('Data kelas berhasil diperbarui.', 'class_form.html', item=item, courses=courses, lecturers=lecturers)
    return render_template('class_form.html', item=item, courses=courses, lecturers=lecturers)


@app.post('/classes/<int:item_id>/delete')
def class_delete(item_id):
    item = CampusClass.query.get_or_404(item_id)
    if item.enrollments:
        flash('Kelas tidak dapat dihapus karena masih memiliki peserta terdaftar.', 'error')
        return redirect(url_for('classes'))
    db.session.delete(item)
    db.session.commit()
    flash('Data kelas berhasil dihapus.', 'success')
    return redirect(url_for('classes'))


@app.route('/enrollments')
def enrollments():
    q = request.args.get('q', '').strip()
    query = Enrollment.query.join(Student).join(CampusClass).join(Course, CampusClass.course_id == Course.id)
    if q:
        query = query.filter(or_(Student.full_name.ilike(f'%{q}%'), Student.nim.ilike(f'%{q}%'), CampusClass.code.ilike(f'%{q}%'), Course.name.ilike(f'%{q}%')))
    items = query.order_by(Enrollment.created_at.desc()).all()
    return render_template('enrollments.html', items=items, q=q)


@app.route('/enrollments/add', methods=['GET', 'POST'])
def enrollment_add():
    students = Student.query.order_by(Student.full_name.asc()).all()
    classes = CampusClass.query.order_by(CampusClass.code.asc()).all()
    if request.method == 'POST':
        item = Enrollment(
            student_id=int(request.form['student_id']),
            campus_class_id=int(request.form['campus_class_id']),
            grade=request.form.get('grade', '').strip() or None,
            note=request.form.get('note', '').strip() or None,
        )
        db.session.add(item)
        return save_and_redirect('Peserta berhasil ditambahkan ke kelas.', 'enrollment_form.html', item=item, students=students, classes=classes)
    return render_template('enrollment_form.html', item=None, students=students, classes=classes)


@app.route('/enrollments/<int:item_id>/edit', methods=['GET', 'POST'])
def enrollment_edit(item_id):
    item = Enrollment.query.get_or_404(item_id)
    students = Student.query.order_by(Student.full_name.asc()).all()
    classes = CampusClass.query.order_by(CampusClass.code.asc()).all()
    if request.method == 'POST':
        item.student_id = int(request.form['student_id'])
        item.campus_class_id = int(request.form['campus_class_id'])
        item.grade = request.form.get('grade', '').strip() or None
        item.note = request.form.get('note', '').strip() or None
        return save_and_redirect('Data peserta kelas berhasil diperbarui.', 'enrollment_form.html', item=item, students=students, classes=classes)
    return render_template('enrollment_form.html', item=item, students=students, classes=classes)


@app.post('/enrollments/<int:item_id>/delete')
def enrollment_delete(item_id):
    item = Enrollment.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    flash('Data peserta kelas berhasil dihapus.', 'success')
    return redirect(url_for('enrollments'))


@app.route('/health')
def healthcheck():
    return {'status': 'ok'}


@app.errorhandler(404)
def page_not_found(_):
    return render_template('error.html', title='404', message='Halaman yang Anda cari tidak ditemukan.'), 404


@app.errorhandler(500)
def internal_error(_):
    db.session.rollback()
    return render_template('error.html', title='500', message='Terjadi kesalahan internal pada aplikasi.'), 500


def save_and_redirect(success_message: str, template_name: str, **context):
    try:
        db.session.commit()
        flash(success_message, 'success')
        endpoint_map = {
            'department_form.html': 'departments',
            'lecturer_form.html': 'lecturers',
            'student_form.html': 'students',
            'course_form.html': 'courses',
            'class_form.html': 'classes',
            'enrollment_form.html': 'enrollments',
        }
        return redirect(url_for(endpoint_map[template_name]))
    except IntegrityError:
        db.session.rollback()
        flash('Penyimpanan gagal. Pastikan tidak ada kode, NIM, NIDN, atau email yang duplikat.', 'error')
        return render_template(template_name, **context)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
