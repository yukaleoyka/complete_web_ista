# Praktikum 3 - Website Pengelolaan Kampus ISTA

Aplikasi ini disiapkan untuk **praktikum 3 Docker Compose / multi-container**.

## Arsitektur
- **nginx**: reverse proxy
- **app**: Flask web application
- **db**: PostgreSQL database
- **adminer**: antarmuka administrasi database

## Fitur
- Dashboard ringkasan data kampus
- CRUD Jurusan
- CRUD Dosen
- CRUD Mahasiswa
- CRUD Mata Kuliah
- CRUD Kelas
- CRUD Peserta Kelas / Enrollments
- Seed data awal otomatis saat database kosong

## Cara Menjalankan
Pastikan Docker dan Docker Compose sudah siap.

```bash
cd ista-campus-management
docker compose up --build -d
```

## Akses
- Aplikasi utama: `http://IP_VM:8080`
- Adminer: `http://IP_VM:8081`

## Kredensial Database untuk Adminer
- **System**: PostgreSQL
- **Server**: db
- **Username**: ista_user
- **Password**: ista_pass
- **Database**: ista_campus

## Menjalankan Ulang / Melihat Status
```bash
docker compose ps
docker compose logs -f
```

## Menghentikan
```bash
docker compose down
```

## Menghapus beserta volume database
```bash
docker compose down -v
```

## Struktur Folder
```text
ista-campus-management/
├── app/
│   ├── app.py
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── static/
│   └── templates/
├── nginx/
│   └── default.conf
├── docker-compose.yml
└── README.md
```
